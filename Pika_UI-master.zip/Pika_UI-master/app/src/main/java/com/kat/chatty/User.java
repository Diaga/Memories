package com.kat.chatty;

import android.net.Uri;
import android.util.Log;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class User {

    @PrimaryKey
    @ColumnInfo
    @NonNull
    private String accessKey;

    @PrimaryKey
    @ColumnInfo
    private String id;

    @ColumnInfo
    private String displayName;

    @ColumnInfo
    private String email;

    @ColumnInfo
    private String photoURI;

    @ColumnInfo
    private String registeredOn;


    static void register(GoogleSignInAccount gsAccount) {
        displayName = gsAccount.getDisplayName();
        id = gsAccount.getId();
        email = gsAccount.getEmail();
        setPhotoURI(gsAccount.getPhotoUrl());
        String[] args = {"id", "displayName", "email", "photoURI"};
        String[] params = {getId(), getDisplayName(), getEmail(), getPhotoURI()};
        String query = Server.queryBuilder(args, params);
        String url = Server.urlBuilder("register", query);
        new registerTask().execute(url);
    }

    static void saveMemory(String memory) {
        saveMemory(memory, "");
    }

    static void saveMemory(String memory, String geoTag) {
        saveMemory(memory, geoTag, null);
    }

    static void saveMemory(String memory, String geoTag, Uri imageUri) {
        ArrayList<java.io.Serializable> array = new ArrayList<>();

        String[] args = {"accessKey", "savedOn", "memory", "geoTag"};
        String[] params = {getAccessKey(), String.valueOf(System.currentTimeMillis()), memory, geoTag};
        String query = Server.queryBuilder(args, params);
        String url = Server.urlBuilder("save", query);
        array.add(url);
        if (imageUri != null) {
            byte[] bytes;
            byte[] buffer = new byte[8192];
            int bytesRead;
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            try {
                InputStream inputStream = new FileInputStream(imageUri.toString());
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }
            } catch (Exception e) {
                Log.d("IMG_TO_BYTE_ERROR: ", e.toString());
            }
            bytes = outputStream.toByteArray();
            array.add(bytes);
        }
        new saveMemoryTask().execute(array);
    }

    static void sendMessage(String message) {
        // To be implemented
    }

    static private void setPhotoURI(Uri param_photoURI) {
        if (param_photoURI != null) {
            photoURI = param_photoURI.toString();
        }
    }

    static void setAccessKey(String param_accessKey) {
        accessKey = param_accessKey;
    }

    @NonNull
    public String getAccessKey() {
        return accessKey;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhotoURI() {
        return photoURI;
    }

    public String getRegisteredOn() {
        return registeredOn;
    }
}
