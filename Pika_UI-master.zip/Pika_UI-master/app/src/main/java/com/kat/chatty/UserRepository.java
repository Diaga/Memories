package com.kat.chatty;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

public class UserRepository {
    private UserDao userDao;
    private LiveData<User> userLiveData;

    UserRepository(Application application) {
        Database db = Database.getDatabase(application);
        userDao = db.userDao();
        userLiveData = userDao.getUser();
    }

    LiveData<User> getUser() {
        return userLiveData;
    }

    public void insert(User user) {
        new insertTask(userDao).execute(user);
    }
}

private static class insertTask extends AsyncTask<User, Void, Void> {
    private UserDao userDao;

    insertTask(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    protected Void doInBackground(User... users) {
        userDao.insert(users[0]);
        return null;
    }
}
