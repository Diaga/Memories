package com.kat.chatty;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

public class UserViewModel extends AndroidViewModel {
    private UserRepository userRepository;
    private LiveData<User> userLiveData;

    public UserViewModel(Application application) {
        super(application);
        userRepository = new UserRepository(application);
        userLiveData = userRepository.getUser();
    }

    public LiveData<User> getUser() {
        return userLiveData;
    }

    public void insertUser(User user) {
        userRepository.insert(user);
    }
}
